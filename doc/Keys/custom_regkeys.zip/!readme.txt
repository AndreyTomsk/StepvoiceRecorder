STEPVOICE RECORDER REGISTRATION

You should run new version of StepVoice Recorder one time
before registration action.

-----------------------------------------------------------
Please open your .key file by double-clicking on it. After
that you'll see the following message:
"Information in <your name>.key been succesfully entered
info the registry".

Then run StepVoice Recorder and you will find your name in
the "About" dialog. If so, all shareware restrictions are
automatically removed from your version.

-----------------------------------------------------------
You can also find your key in the <your name>.txt file. To
register the program just copy the key and then paste it in
the program registration dialog. You can open it by program
menu "Help | Program registration | Enter registration key".


We hope that you'll enjoy using our program!